import os
import sqlite3
import click
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
from database import connect_db, setup_db
from config import Config

app = Flask(__name__)
app.config.from_object(Config)
csrf = CSRFProtect(app)

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("سجّل الدخول أولاً")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "admin":
            flash("هذه الصفحة للإدارة فقط")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped

@app.route("/")
def home():
    category = request.args.get("category", "").strip()
    allowed = ["عام", "دروس ومناهج", "أخبار المدرسة", "أسئلة ومناقشات", "أنشطة وفعاليات"]
    if category not in allowed:
        category = ""

    db = connect_db()
    query = """
        SELECT posts.*, users.username,
        (SELECT COUNT(*) FROM likes WHERE likes.post_id=posts.id) AS likes_count,
        (SELECT COUNT(*) FROM comments WHERE comments.post_id=posts.id) AS comments_count
        FROM posts JOIN users ON users.id=posts.user_id
        WHERE posts.status='approved'
    """
    params = []
    if category:
        query += " AND posts.category=?"
        params.append(category)
    query += " ORDER BY posts.id DESC"
    posts = db.execute(query, params).fetchall()
    post_comments = {}
    for post in posts:
        post_comments[post["id"]] = db.execute("""
            SELECT comments.content, users.username
            FROM comments JOIN users ON users.id=comments.user_id
            WHERE comments.post_id=?
            ORDER BY comments.id ASC
        """, (post["id"],)).fetchall()
    db.close()
    return render_template("index.html", posts=posts, post_comments=post_comments, category=category)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        if len(username) < 3 or len(username) > 30:
            flash("اسم المستخدم يجب أن يكون بين 3 و30 حرفاً")
            return redirect(url_for("register"))

        if len(password) < 10:
            flash("كلمة المرور يجب أن تكون 10 أحرف على الأقل")
            return redirect(url_for("register"))

        db = connect_db()
        try:
            db.execute(
                "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                (username, generate_password_hash(password))
            )
            db.commit()
            flash("تم إنشاء الحساب. انتظر موافقة الإدارة قبل النشر.")
        except sqlite3.IntegrityError:
            flash("اسم المستخدم مستخدم مسبقاً")
        finally:
            db.close()

        return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        db = connect_db()
        user = db.execute(
            "SELECT * FROM users WHERE username=?", (username,)
        ).fetchone()
        db.close()

        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            session["approved"] = user["approved"]
            return redirect(url_for("dashboard"))

        flash("اسم المستخدم أو كلمة المرور غير صحيحة")

    return render_template("login.html")

@app.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html")

@app.route("/post", methods=["POST"])
@login_required
def create_post():
    if not session.get("approved") or session.get("role") != "student":
        flash("حسابك يحتاج موافقة الإدارة قبل النشر")
        return redirect(url_for("dashboard"))

    content = request.form.get("content", "").strip()
    category = request.form.get("category", "عام").strip()
    allowed = ["عام", "دروس ومناهج", "أخبار المدرسة", "أسئلة ومناقشات", "أنشطة وفعاليات"]
    if category not in allowed:
        category = "عام"

    if not content or len(content) > 2000:
        flash("اكتب منشوراً لا يتجاوز 2000 حرف")
        return redirect(url_for("home"))

    db = connect_db()
    db.execute(
        "INSERT INTO posts (user_id, content, category, status) VALUES (?, ?, ?, 'pending')",
        (session["user_id"], content, category)
    )
    db.commit()
    db.close()

    return redirect(url_for("home"))

@app.route("/admin")
@login_required
@admin_required
def admin_dashboard():
    db = connect_db()
    pending = db.execute(
        "SELECT id, username FROM users WHERE approved=0 AND role='student'"
    ).fetchall()
    users = db.execute(
        "SELECT id, username, approved FROM users WHERE role='student'"
    ).fetchall()
    pending_posts = db.execute("""
        SELECT posts.id, posts.content, posts.category, users.username
        FROM posts JOIN users ON users.id=posts.user_id
        WHERE posts.status='pending'
        ORDER BY posts.id DESC
    """).fetchall()

    reports = db.execute("""
        SELECT reports.id, reports.reason, reports.created_at,
        posts.content, users.username
        FROM reports
        JOIN posts ON posts.id=reports.post_id
        JOIN users ON users.id=reports.user_id
        WHERE reports.status='pending'
        ORDER BY reports.id DESC
    """).fetchall()

    comments = db.execute("""
        SELECT comments.id, comments.content, users.username
        FROM comments JOIN users ON users.id=comments.user_id
        ORDER BY comments.id DESC
    """).fetchall()

    db.close()
    return render_template(
        "admin/dashboard.html",
        pending=pending, users=users, pending_posts=pending_posts,
        reports=reports, comments=comments
    )

@app.route("/admin/approve/<int:user_id>", methods=["POST"])
@login_required
@admin_required
def approve_user(user_id):
    db = connect_db()
    db.execute(
        "UPDATE users SET approved=1 WHERE id=? AND role='student'",
        (user_id,)
    )
    db.commit()
    db.close()
    flash("تمت الموافقة على الحساب")
    return redirect(url_for("admin_dashboard"))

@app.route("/admin/delete-post/<int:post_id>", methods=["POST"])
@login_required
@admin_required
def delete_post(post_id):
    db = connect_db()
    db.execute("DELETE FROM likes WHERE post_id=?", (post_id,))
    db.execute("DELETE FROM comments WHERE post_id=?", (post_id,))
    db.execute("DELETE FROM posts WHERE id=?", (post_id,))
    db.commit()
    db.close()
    flash("تم حذف المنشور")
    return redirect(url_for("home"))

@app.cli.command("create-admin")
@click.argument("username")
def create_admin(username):
    """إنشاء حساب إدارة بكلمة مرور تُدخل بشكل مخفي."""
    import getpass
    setup_db()
    password = getpass.getpass("كلمة مرور الإدارة: ")
    if len(password) < 14:
        click.echo("اجعل كلمة المرور 14 حرفاً على الأقل.")
        return

    db = connect_db()
    try:
        db.execute(
            "INSERT INTO users (username, password_hash, role, approved) VALUES (?, ?, 'admin', 1)",
            (username, generate_password_hash(password))
        )
        db.commit()
        click.echo("تم إنشاء حساب الإدارة.")
    except sqlite3.IntegrityError:
        click.echo("اسم المستخدم موجود مسبقاً.")
    finally:
        db.close()


@app.route("/like/<int:post_id>", methods=["POST"])
@login_required
def toggle_like(post_id):
    if session.get("role") != "student" or not session.get("approved"):
        flash("يجب أن يكون حسابك موافقاً عليه للتفاعل")
        return redirect(url_for("home"))

    db = connect_db()
    post = db.execute(
        "SELECT id FROM posts WHERE id=?", (post_id,)
    ).fetchone()

    if not post:
        db.close()
        flash("المنشور غير موجود")
        return redirect(url_for("home"))

    existing = db.execute(
        "SELECT id FROM likes WHERE post_id=? AND user_id=?",
        (post_id, session["user_id"])
    ).fetchone()

    if existing:
        db.execute("DELETE FROM likes WHERE id=?", (existing["id"],))
    else:
        db.execute(
            "INSERT INTO likes (post_id, user_id) VALUES (?, ?)",
            (post_id, session["user_id"])
        )

    db.commit()
    db.close()
    return redirect(url_for("home"))


@app.route("/comment/<int:post_id>", methods=["POST"])
@login_required
def add_comment(post_id):
    if session.get("role") != "student" or not session.get("approved"):
        flash("يجب أن يكون حسابك موافقاً عليه للتعليق")
        return redirect(url_for("home"))

    content = request.form.get("content", "").strip()
    category = request.form.get("category", "عام").strip()
    allowed = ["عام", "دروس ومناهج", "أخبار المدرسة", "أسئلة ومناقشات", "أنشطة وفعاليات"]
    if category not in allowed:
        category = "عام"

    if not content or len(content) > 500:
        flash("التعليق مطلوب ويجب ألا يتجاوز 500 حرف")
        return redirect(url_for("home"))

    db = connect_db()
    post = db.execute(
        "SELECT id FROM posts WHERE id=?", (post_id,)
    ).fetchone()

    if not post:
        db.close()
        flash("المنشور غير موجود")
        return redirect(url_for("home"))

    db.execute(
        "INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)",
        (post_id, session["user_id"], content)
    )
    db.commit()
    db.close()
    return redirect(url_for("home"))


@app.route("/search")
def search():
    query = request.args.get("q", "").strip()[:80]
    db = connect_db()

    posts = db.execute("""
        SELECT posts.*, users.username,
        (SELECT COUNT(*) FROM likes WHERE likes.post_id=posts.id) AS likes_count,
        (SELECT COUNT(*) FROM comments WHERE comments.post_id=posts.id) AS comments_count
        FROM posts JOIN users ON users.id=posts.user_id
        WHERE posts.content LIKE ? AND posts.status='approved'
        ORDER BY posts.id DESC
    """, ("%" + query + "%",)).fetchall()

    comments = {}
    for post in posts:
        comments[post["id"]] = db.execute("""
            SELECT comments.content, users.username
            FROM comments JOIN users ON users.id=comments.user_id
            WHERE comments.post_id=?
            ORDER BY comments.id ASC
        """, (post["id"],)).fetchall()

    db.close()
    return render_template(
        "search.html", posts=posts, comments=comments, query=query
    )


@app.route("/report/<int:post_id>", methods=["POST"])
@login_required
def report_post(post_id):
    if session.get("role") != "student" or not session.get("approved"):
        flash("يجب موافقة الإدارة على حسابك أولاً")
        return redirect(url_for("home"))

    reason = request.form.get("reason", "").strip()
    if not reason or len(reason) > 300:
        flash("اكتب سبباً مختصراً للبلاغ")
        return redirect(url_for("home"))

    db = connect_db()
    post = db.execute(
        "SELECT id FROM posts WHERE id=?", (post_id,)
    ).fetchone()

    if not post:
        db.close()
        flash("المنشور غير موجود")
        return redirect(url_for("home"))

    db.execute(
        "INSERT INTO reports (post_id, user_id, reason) VALUES (?, ?, ?)",
        (post_id, session["user_id"], reason)
    )
    db.commit()
    db.close()
    flash("تم إرسال البلاغ للإدارة")
    return redirect(url_for("home"))


@app.route("/admin/delete-comment/<int:comment_id>", methods=["POST"])
@login_required
@admin_required
def delete_comment(comment_id):
    db = connect_db()
    db.execute("DELETE FROM comments WHERE id=?", (comment_id,))
    db.commit()
    db.close()
    flash("تم حذف التعليق")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/report/<int:report_id>/<action>", methods=["POST"])
@login_required
@admin_required
def handle_report(report_id, action):
    if action not in ("dismiss", "remove"):
        return redirect(url_for("admin_dashboard"))

    db = connect_db()
    report = db.execute(
        "SELECT post_id FROM reports WHERE id=? AND status='pending'",
        (report_id,)
    ).fetchone()

    if report:
        if action == "remove":
            post_id = report["post_id"]
            db.execute("DELETE FROM likes WHERE post_id=?", (post_id,))
            db.execute("DELETE FROM comments WHERE post_id=?", (post_id,))
            db.execute("DELETE FROM reports WHERE post_id=?", (post_id,))
            db.execute("DELETE FROM posts WHERE id=?", (post_id,))
        else:
            db.execute(
                "UPDATE reports SET status='dismissed' WHERE id=?",
                (report_id,)
            )

    db.commit()
    db.close()
    flash("تمت معالجة البلاغ")
    return redirect(url_for("admin_dashboard"))


@app.route("/edit-post/<int:post_id>", methods=["GET", "POST"])
@login_required
def edit_post(post_id):
    if session.get("role") != "student" or not session.get("approved"):
        flash("لا تملك صلاحية تعديل المنشورات")
        return redirect(url_for("home"))

    db = connect_db()
    post = db.execute(
        "SELECT * FROM posts WHERE id=? AND user_id=? AND status='approved'",
        (post_id, session["user_id"])
    ).fetchone()

    if not post:
        db.close()
        flash("المنشور غير موجود أو لا تملك صلاحية تعديله")
        return redirect(url_for("home"))

    if request.method == "POST":
        content = request.form.get("content", "").strip()
        category = request.form.get("category", "عام").strip()
        allowed = ["عام", "دروس ومناهج", "أخبار المدرسة", "أسئلة ومناقشات", "أنشطة وفعاليات"]

        if not content or len(content) > 2000:
            flash("المنشور مطلوب ولا يتجاوز 2000 حرف")
        else:
            if category not in allowed:
                category = "عام"

            db.execute(
                "UPDATE posts SET content=?, category=? WHERE id=? AND user_id=?",
                (content, category, post_id, session["user_id"])
            )
            db.commit()
            db.close()
            flash("تم تعديل المنشور")
            return redirect(url_for("home"))

    db.close()
    return render_template("edit_post.html", post=post)


@app.route("/admin/approve-post/<int:post_id>", methods=["POST"])
@login_required
@admin_required
def approve_post(post_id):
    db = connect_db()
    db.execute(
        "UPDATE posts SET status='approved' WHERE id=?",
        (post_id,)
    )
    db.commit()
    db.close()
    flash("تمت الموافقة على المنشور")
    return redirect(url_for("admin_dashboard"))

if __name__ == "__main__":
    setup_db()
    app.run(host="127.0.0.1", port=8000, debug=False)


# Notifications
import sqlite3 as _notif_sqlite
from flask import render_template as _notif_render, redirect as _notif_redirect
from flask import url_for as _notif_url, abort as _notif_abort
from flask_login import login_required as _notif_login_required
from flask_login import current_user as _notif_current_user


@app.context_processor
def unread_notifications_count():
    if not session.get("user_id"):
        return {"unread_notifications": 0}

    db = connect_db()
    count = db.execute(
        "SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0",
        (session["user_id"],)
    ).fetchone()[0]
    db.close()
    return {"unread_notifications": count}


@app.route("/notifications/read-all", methods=["POST"])
@login_required
def read_all_notifications():
    db = connect_db()
    db.execute(
        "UPDATE notifications SET is_read=1 WHERE user_id=?",
        (session["user_id"],)
    )
    db.commit()
    db.close()
    flash("تم تعليم جميع الإشعارات كمقروءة")
    return redirect(url_for("notifications"))


@app.route("/notifications")
@_notif_login_required
def notifications():
    conn = _notif_sqlite.connect("forum.db")
    conn.row_factory = _notif_sqlite.Row
    items = conn.execute(
        """SELECT * FROM notifications
           WHERE user_id = ?
           ORDER BY created_at DESC""",
        (_notif_current_user.id,)
    ).fetchall()
    conn.close()
    return _notif_render("notifications.html", notifications=items)


@app.route("/notifications/read/<int:notification_id>", methods=["POST"])
@_notif_login_required
def read_notification(notification_id):
    conn = _notif_sqlite.connect("forum.db")
    conn.execute(
        """UPDATE notifications SET is_read = 1
           WHERE id = ? AND user_id = ?""",
        (notification_id, _notif_current_user.id)
    )
    conn.commit()
    conn.close()
    return _notif_redirect(_notif_url("notifications"))
