from pathlib import Path

p = Path("app.py")
s = p.read_text()

def replace_once(old, new, label):
    global s
    count = s.count(old)
    if count != 1:
        raise SystemExit(f"توقف: لم أجد موضع {label} مرة واحدة بالضبط.")
    s = s.replace(old, new, 1)

# دالة مساعدة لإنشاء الإشعارات
marker = '@app.route("/like/<int:post_id>", methods=["POST"])'
helper = '''def add_notification(db, user_id, message, link=None):
    db.execute(
        """INSERT INTO notifications (user_id, message, link)
           VALUES (?, ?, ?)""",
        (user_id, message, link)
    )


'''
if "def add_notification(db," not in s:
    if s.count(marker) != 1:
        raise SystemExit("لم أجد مكان إضافة دالة الإشعارات.")
    s = s.replace(marker, helper + marker, 1)

# الإعجاب
replace_once(
    '"SELECT id FROM posts WHERE id=?", (post_id,)',
    '"SELECT id, user_id FROM posts WHERE id=?", (post_id,)',
    "استعلام المنشور"
)

replace_once(
    '''        db.execute(
            "INSERT INTO likes (post_id, user_id) VALUES (?, ?)",
            (post_id, session["user_id"])
        )''',
    '''        db.execute(
            "INSERT INTO likes (post_id, user_id) VALUES (?, ?)",
            (post_id, session["user_id"])
        )
        if post["user_id"] != session["user_id"]:
            add_notification(
                db, post["user_id"], "أحد الطلاب أعجب بمنشورك",
                f"/"
            )''',
    "إشعار الإعجاب"
)

# التعليق: نحتاج معرفة صاحب المنشور
replace_once(
    '"SELECT id FROM posts WHERE id=?", (post_id,)',
    '"SELECT id, user_id FROM posts WHERE id=?", (post_id,)',
    "استعلام صاحب المنشور"
)

replace_once(
    '''    db.execute(
        "INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)",
        (post_id, session["user_id"], content)
    )
    db.commit()''',
    '''    db.execute(
        "INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)",
        (post_id, session["user_id"], content)
    )
    if post["user_id"] != session["user_id"]:
        add_notification(
            db, post["user_id"], "أضاف أحد الطلاب تعليقاً على منشورك",
            "/"
        )
    db.commit()''',
    "إشعار التعليق"
)

# الموافقة على المنشور
replace_once(
    '''    db = connect_db()
    db.execute(
        "UPDATE posts SET status='approved' WHERE id=?",
        (post_id,)
    )
    db.commit()
    db.close()
    flash("تمت الموافقة على المنشور")''',
    '''    db = connect_db()
    post = db.execute(
        "SELECT user_id FROM posts WHERE id=?", (post_id,)
    ).fetchone()

    if post:
        db.execute(
            "UPDATE posts SET status='approved' WHERE id=?",
            (post_id,)
        )
        add_notification(
            db, post["user_id"], "وافقت الإدارة على منشورك",
            "/"
        )
        db.commit()
        flash("تمت الموافقة على المنشور وإرسال إشعار لصاحبه")
    else:
        flash("المنشور غير موجود")
    db.close()''',
    "إشعار الموافقة"
)

p.write_text(s)
print("تم ربط إشعارات الإعجاب والتعليق والموافقة بنجاح 🔔")
