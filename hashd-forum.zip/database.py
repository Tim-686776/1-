import sqlite3

DB_NAME = "forum.db"

def connect_db():
    db = sqlite3.connect(DB_NAME)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db

def setup_db():
    db = connect_db()

    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'student',
        approved INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'عام',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        post_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'عام',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(post_id) REFERENCES posts(id),
        FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        post_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        reason TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(post_id) REFERENCES posts(id),
        FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS likes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        post_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        UNIQUE(post_id, user_id),
        FOREIGN KEY(post_id) REFERENCES posts(id),
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)

    columns = [row["name"] for row in db.execute("PRAGMA table_info(posts)").fetchall()]
    if "status" not in columns:
        db.execute("ALTER TABLE posts ADD COLUMN status TEXT NOT NULL DEFAULT 'approved'")
        db.execute("UPDATE posts SET status='approved'")

    if "category" not in columns:
        db.execute("ALTER TABLE posts ADD COLUMN category TEXT NOT NULL DEFAULT 'عام'")

    db.commit()
    db.close()


def create_notification(user_id, message, link=None):
    import sqlite3

    conn = sqlite3.connect("forum.db")
    conn.execute(
        """INSERT INTO notifications (user_id, message, link)
           VALUES (?, ?, ?)""",
        (user_id, message, link)
    )
    conn.commit()
    conn.close()
